/*****************************************************************************

  switch_clk.h - This is the interface file for the synchronous process 
                 "switch_clk".

 *****************************************************************************/

#ifndef SWITCH_CLK_H
#define SWITCH_CLK_H

struct switch_clk : sc_module {
    sc_out<bool> switch_cntrl;
    sc_in_clk CLK;

    SC_CTOR(switch_clk) {
        SC_METHOD(entry);
        dont_initialize();
        sensitive << CLK.pos();
    }
    void entry();
};

#endif
