/*****************************************************************************

  receiver.cpp - This is the implementation file for the asynchronous process
                 "receiver".

 *****************************************************************************/

#include "pkt.h"
#include "receiver.h"

void receiver::entry() {
    pkt temp_val;

    temp_val = pkt_in.read();
    cout << "                                  .........................." << endl;
    cout << "                                  " << "\33[32m" << sc_time_stamp() << ": " << "\33[31m" << "New Packet Received" << "\33[0m" << endl;
    cout << "                                  Receiver ID: " << (int) sink_id.read() + 1 << endl;
    cout << "                                  Packet Value: " << (int) temp_val.data << endl;
    cout << "                                  Sender ID: " << (int) temp_val.id + 1 << endl;
    cout << "                                  .........................." << endl;
}
