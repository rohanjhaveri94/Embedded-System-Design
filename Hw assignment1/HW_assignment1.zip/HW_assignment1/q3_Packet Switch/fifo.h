/*****************************************************************************

  fifo.h - This is the header file for the SystemC structure "fifo".

 *****************************************************************************/

#ifndef FIFO_H
#define FIFO_H

struct fifo {
    pkt regs[8];
    bool full;
    bool empty;
    sc_uint < 3 > pntr;

    // constructor

    fifo() {
        full = false;
        empty = true;
        pntr = 0;
    };

    // methods   
    void pkt_in(const pkt & data_pkt);

    pkt pkt_out();
};

#endif
