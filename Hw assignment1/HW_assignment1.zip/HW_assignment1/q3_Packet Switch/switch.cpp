/*****************************************************************************

  switch.cpp - This is the implementation file for the asynchronous process
               "switch".

 *****************************************************************************/

#include "systemc.h"
#include "pkt.h"
#include "fifo.h"
#include "switch_reg.h"
#include "switch.h"

#define SIM_NUM 5000

void mcast_pkt_switch::entry() {
    wait();

    // declarations
    switch_reg R0;
    switch_reg R1;
    switch_reg R2;
    switch_reg R3;
    switch_reg R4;
    switch_reg R5;
    switch_reg R6;
    switch_reg R7;
    switch_reg temp;

    int sim_count;
    int pkt_count;
    int drop_count;

    fifo q0_in;
    fifo q1_in;
    fifo q2_in;
    fifo q3_in;
    fifo q4_in;
    fifo q5_in;
    fifo q6_in;
    fifo q7_in;

    fifo q0_out;
    fifo q1_out;
    fifo q2_out;
    fifo q3_out;
    fifo q4_out;
    fifo q5_out;
    fifo q6_out;
    fifo q7_out;

    // initialization
    pkt_count = 0;
    drop_count = 0;
    sim_count = 0;

    q0_in.pntr = 0;
    q1_in.pntr = 0;
    q2_in.pntr = 0;
    q3_in.pntr = 0;
    q4_in.pntr = 0;
    q5_in.pntr = 0;
    q6_in.pntr = 0;
    q7_in.pntr = 0;

    q0_out.pntr = 0;
    q1_out.pntr = 0;
    q2_out.pntr = 0;
    q3_out.pntr = 0;
    q4_out.pntr = 0;
    q5_out.pntr = 0;
    q6_out.pntr = 0;
    q7_out.pntr = 0;

    q0_in.full = false;
    q1_in.full = false;
    q2_in.full = false;
    q3_in.full = false;
    q4_in.full = false;
    q5_in.full = false;
    q6_in.full = false;
    q7_in.full = false;

    q0_in.empty = true;
    q1_in.empty = true;
    q2_in.empty = true;
    q3_in.empty = true;
    q4_in.empty = true;
    q5_in.empty = true;
    q6_in.empty = true;
    q7_in.empty = true;

    q0_out.full = false;
    q1_out.full = false;
    q2_out.full = false;
    q3_out.full = false;
    q4_out.full = false;
    q5_out.full = false;
    q6_out.full = false;
    q7_out.full = false;

    q0_out.empty = true;
    q1_out.empty = true;
    q2_out.empty = true;
    q3_out.empty = true;
    q4_out.empty = true;
    q5_out.empty = true;
    q6_out.empty = true;
    q7_out.empty = true;

    R0.free = true;
    R1.free = true;
    R2.free = true;
    R3.free = true;
    R4.free = true;
    R5.free = true;
    R6.free = true;
    R7.free = true;

    cout << endl;
    cout << "-------------------------------------------------------------------------------" << endl;
    cout << endl << "             8x8 Multicast Helix Packet Switch Simulation" << endl;
    cout << "-------------------------------------------------------------------------------" << endl;
    cout << "  This is the simulation of a 8x8 non-blocking multicast helix packet switch.  " << endl;
    cout << "  The switch uses a self-routing ring of shift registers to transfer cells     " << endl;
    cout << "  from one port to another in a pipelined fashion, resolving output contention " << endl;
    cout << "  and handling multicast switch efficiently." << endl << endl;

    cout << "  Press \"Return\" key to start the simulation..." << endl << endl;

    getchar();

    wait();
    // functionality
    while (sim_count++ < SIM_NUM) {
        wait();

        /////read input packets//////////////////////////////////     
        if (in0.event()) {
            pkt_count++;
            if (q0_in.full == true) drop_count++;
            else q0_in.pkt_in(in0.read());
        };

        if (in1.event()) {
            pkt_count++;
            if (q1_in.full == true) drop_count++;
            else q1_in.pkt_in(in1.read());
        };

        if (in2.event()) {
            pkt_count++;
            if (q2_in.full == true) drop_count++;
            else q2_in.pkt_in(in2.read());
        };

        if (in3.event()) {
            pkt_count++;
            if (q3_in.full == true) drop_count++;
            else q3_in.pkt_in(in3.read());
        };

        if (in4.event()) {
            pkt_count++;
            if (q4_in.full == true) drop_count++;
            else q4_in.pkt_in(in4.read());
        };

        if (in5.event()) {
            pkt_count++;
            if (q5_in.full == true) drop_count++;
            else q5_in.pkt_in(in5.read());
        };

        if (in6.event()) {
            pkt_count++;
            if (q6_in.full == true) drop_count++;
            else q6_in.pkt_in(in6.read());
        };

        if (in7.event()) {
            pkt_count++;
            if (q7_in.full == true) drop_count++;
            else q7_in.pkt_in(in7.read());
        };




        /////move the packets from fifo to shift register ring/////

        if ((!q0_in.empty) && R0.free) {
            R0.val = q0_in.pkt_out();
            R0.free = false;
        }

        if ((!q1_in.empty) && R1.free) {
            R1.val = q1_in.pkt_out();
            R1.free = false;
        }
        if ((!q2_in.empty) && R2.free) {
            R2.val = q2_in.pkt_out();
            R2.free = false;
        }
        if ((!q3_in.empty) && R3.free) {
            R3.val = q3_in.pkt_out();
            R3.free = false;
        }
        if ((!q4_in.empty) && R4.free) {
            R4.val = q4_in.pkt_out();
            R4.free = false;
        }
        if ((!q5_in.empty) && R5.free) {
            R5.val = q5_in.pkt_out();
            R5.free = false;
        }
        if ((!q6_in.empty) && R6.free) {
            R6.val = q6_in.pkt_out();
            R6.free = false;
        }
        if ((!q7_in.empty) && R7.free) {
            R7.val = q7_in.pkt_out();
            R7.free = false;
        }
        if ((bool)switch_cntrl && switch_cntrl.event()) {
            /////shift the channel registers /////////////////////////
            temp = R0;
            R0 = R1;
            R1 = R2;
            R2 = R3;
	    R3 = R4;
	    R4 = R5;
	    R5 = R6;
	    R6 = R7;
            R7 = temp;

            /////write the register values to output fifos////////////
            if ((!R0.free) && (R0.val.dest0) && (!q0_out.full)) {
                q0_out.pkt_in(R0.val);
                R0.val.dest0 = false;
                if (!(R0.val.dest0 | R0.val.dest1 | R0.val.dest2 | R0.val.dest3 | R0.val.dest4 | R0.val.dest5 | R0.val.dest6 | R0.val.dest7)) R0.free = true;
            }

            if ((!R1.free) && (R1.val.dest1) && (!q1_out.full)) {
                q1_out.pkt_in(R1.val);
                R1.val.dest1 = false;
                if (!(R1.val.dest1 | R1.val.dest1 | R1.val.dest2 | R1.val.dest3 | R1.val.dest4 | R1.val.dest5 | R1.val.dest6 | R1.val.dest7)) R1.free = true;
            }
            if ((!R2.free) && (R2.val.dest2) && (!q2_out.full)) {
                q2_out.pkt_in(R2.val);
                R2.val.dest2 = false;
                if (!(R2.val.dest2 | R2.val.dest1 | R2.val.dest2 | R2.val.dest3 | R2.val.dest4 | R2.val.dest5 | R2.val.dest6 | R2.val.dest7)) R2.free = true;
            }
            if ((!R3.free) && (R3.val.dest3) && (!q3_out.full)) {
                q3_out.pkt_in(R3.val);
                R3.val.dest3 = false;
                if (!(R3.val.dest3 | R3.val.dest1 | R3.val.dest2 | R3.val.dest3 | R3.val.dest4 | R3.val.dest5 | R3.val.dest6 | R3.val.dest7)) R3.free = true;
            }
            if ((!R4.free) && (R4.val.dest4) && (!q4_out.full)) {
                q4_out.pkt_in(R4.val);
                R4.val.dest4 = false;
                if (!(R4.val.dest4 | R4.val.dest1 | R4.val.dest2 | R4.val.dest3 | R4.val.dest4 | R4.val.dest5 | R4.val.dest6 | R4.val.dest7)) R4.free = true;
            }
            if ((!R5.free) && (R5.val.dest5) && (!q5_out.full)) {
                q5_out.pkt_in(R5.val);
                R5.val.dest5 = false;
                if (!(R5.val.dest5 | R5.val.dest1 | R5.val.dest2 | R5.val.dest3 | R5.val.dest4 | R5.val.dest5 | R5.val.dest6 | R5.val.dest7)) R5.free = true;
            }
            if ((!R6.free) && (R6.val.dest6) && (!q6_out.full)) {
                q6_out.pkt_in(R6.val);
                R6.val.dest6 = false;
                if (!(R6.val.dest6 | R6.val.dest1 | R6.val.dest2 | R6.val.dest3 | R6.val.dest4 | R6.val.dest5 | R6.val.dest6 | R6.val.dest7)) R6.free = true;
            }
            if ((!R7.free) && (R7.val.dest7) && (!q7_out.full)) {
                q7_out.pkt_in(R7.val);
                R7.val.dest7 = false;
                if (!(R7.val.dest7 | R7.val.dest1 | R7.val.dest2 | R7.val.dest3 | R7.val.dest4 | R7.val.dest5 | R7.val.dest6 | R7.val.dest7)) R7.free = true;
            }
            /////write the packets out//////////////////////////////////    
            if (!q0_out.empty) out0.write(q0_out.pkt_out());
            if (!q1_out.empty) out1.write(q1_out.pkt_out());
            if (!q2_out.empty) out2.write(q2_out.pkt_out());
            if (!q3_out.empty) out3.write(q3_out.pkt_out());
            if (!q4_out.empty) out3.write(q4_out.pkt_out());
            if (!q5_out.empty) out3.write(q5_out.pkt_out());
            if (!q6_out.empty) out3.write(q6_out.pkt_out());
            if (!q7_out.empty) out3.write(q7_out.pkt_out());
        }
    }

    sc_stop();

    cout << endl << endl << "-------------------------------------------------------------------------------" << endl;
    cout << "End of switch operation..." << endl;
    cout << "Total number of packets received: " << pkt_count << endl;
    cout << "Total number of packets dropped: " << drop_count << endl;
    cout << "Percentage packets dropped:  " << drop_count * 100 / pkt_count << endl;
    cout << "-------------------------------------------------------------------------------" << endl;

}
