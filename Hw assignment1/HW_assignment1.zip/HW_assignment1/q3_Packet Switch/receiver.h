/*****************************************************************************

  receiver.h - This is the interface file for the asynchronous process
               "receiver".

 *****************************************************************************/

#ifndef RECEIVER_H
#define RECEIVER_H

struct receiver : sc_module {
    sc_in<pkt> pkt_in;
    sc_in<sc_int < 4 > > sink_id;
    int first;

    SC_CTOR(receiver) {
        SC_METHOD(entry);
        dont_initialize();
        sensitive << pkt_in;
        first = 1;
    }
    void entry();
};

#endif
