/*****************************************************************************

  switch_clk.cpp - This is the implementation file for the synchronous process
                   "switch_clk".

 *****************************************************************************/

#include "systemc.h"
#include "switch_clk.h"

void switch_clk::entry() {
    static bool var_switch_cntrl = false;
    {
        switch_cntrl = var_switch_cntrl;
        var_switch_cntrl = !var_switch_cntrl;
    }
}

