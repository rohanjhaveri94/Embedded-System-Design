/*****************************************************************************

  sender.h - This is the interface file for the synchronous process "sender".

 *****************************************************************************/

#ifndef SENDER_H
#define SENDER_H

struct sender : sc_module {
    sc_out<pkt> pkt_out;
    sc_in<sc_int < 4 > > source_id;
    sc_in_clk CLK;

    SC_CTOR(sender) {
        SC_CTHREAD(entry, CLK.pos());
    }
    void entry();
};

#endif
