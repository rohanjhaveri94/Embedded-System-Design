/*****************************************************************************

  switch_reg.h - This file describes a SystemC structure "switch_reg".

 *****************************************************************************/

#ifndef SWITCH_REG_H
#define SWITCH_REG_H

struct switch_reg {
    pkt val;
    bool free;

    // constructor

    switch_reg() {
        free = true;
    }
};

#endif
