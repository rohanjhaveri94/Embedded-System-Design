/*****************************************************************************

  switch.h - This is the interface file for the asynchronous process "switch".

 *****************************************************************************/

#ifndef SWITCH_H
#define SWITCH_H

struct mcast_pkt_switch : sc_module {
    sc_in<bool> switch_cntrl;
    sc_in<pkt> in0;
    sc_in<pkt> in1;
    sc_in<pkt> in2;
    sc_in<pkt> in3;
    sc_in<pkt> in4;
    sc_in<pkt> in5;
    sc_in<pkt> in6;
    sc_in<pkt> in7;


    sc_out<pkt> out0;
    sc_out<pkt> out1;
    sc_out<pkt> out2;
    sc_out<pkt> out3;
    sc_out<pkt> out4;
    sc_out<pkt> out5;
    sc_out<pkt> out6;
    sc_out<pkt> out7;

    SC_CTOR(mcast_pkt_switch) {
        SC_THREAD(entry);
        sensitive << in0;
        sensitive << in1;
        sensitive << in2;
        sensitive << in3;
        sensitive << in4;
        sensitive << in5;
        sensitive << in6;
        sensitive << in7;
        sensitive << switch_cntrl.pos();
    }

    void entry();
};

#endif
