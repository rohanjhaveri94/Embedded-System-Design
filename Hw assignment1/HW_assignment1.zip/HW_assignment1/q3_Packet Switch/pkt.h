/*****************************************************************************

  pkt.h - This file defines a SystemC structure "pkt".

 *****************************************************************************/

#ifndef PKT_H
#define PKT_H

#include "systemc.h"

struct pkt {
    sc_int < 8 > data;
    sc_int < 4 > id;
    bool dest0;
    bool dest1;
    bool dest2;
    bool dest3;
    bool dest4;
    bool dest5;
    bool dest6;
    bool dest7;

    inline bool operator ==(const pkt & rhs) const {
        return (rhs.data == data && rhs.id == id && rhs.dest0 == dest0 && rhs.dest1 == dest1 && rhs.dest2 == dest2 && rhs.dest3 == dest3 && rhs.dest4 == dest4 && rhs.dest5 == dest5 && rhs.dest6 == dest6 && rhs.dest7 == dest7 );
    }

};

inline
ostream&
operator <<(ostream& os, const pkt& a) {
    os << "streaming of struct pkt not implemented";
    return os;
}

inline
void
    sc_trace(sc_trace_file* tf, const pkt& a, const std::string& name) {
    sc_trace(tf, a.data, name + ".data");
    sc_trace(tf, a.id, name + ".id");
    sc_trace(tf, a.dest0, name + ".dest0");
    sc_trace(tf, a.dest1, name + ".dest1");
    sc_trace(tf, a.dest2, name + ".dest2");
    sc_trace(tf, a.dest3, name + ".dest3");
    sc_trace(tf, a.dest4, name + ".dest4");
    sc_trace(tf, a.dest5, name + ".dest5");
    sc_trace(tf, a.dest6, name + ".dest6");
    sc_trace(tf, a.dest7, name + ".dest7");
}

#endif
