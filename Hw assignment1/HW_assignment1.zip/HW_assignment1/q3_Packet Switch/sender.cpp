/*****************************************************************************

  sender.cpp - This is the implementation file for the synchronous process
               "sender".

 *****************************************************************************/

#include "systemc.h"
#include "pkt.h"
#include "sender.h"
#include "stdlib.h"
#include "time.h"

#define ROUND 2

void sender::entry() {
    pkt pkt_data;
    sc_uint < 8 > dest;

    int round_count = 0;

    srand((unsigned) time(NULL));
    wait(8);
    while (round_count < ROUND) {
        /////generate an 8-bit random value for data//////////
        pkt_data.data = rand() % 255;

        ////stamp the sender's id
        pkt_data.id = source_id.read();


        /////send it to 1 or more(<=4) destinations//////////////
        dest = rand() % 15 + 1;
        pkt_data.dest0 = dest[0];
        pkt_data.dest1 = dest[1];
        pkt_data.dest2 = dest[2];
        pkt_data.dest3 = dest[3];
	pkt_data.dest4 = dest[4];
	pkt_data.dest5 = dest[5];
	pkt_data.dest6 = dest[6];
	pkt_data.dest7 = dest[7];
        pkt_out.write(pkt_data);

        cout << ".........................." << endl;
        cout << "\33[32m" << sc_time_stamp() << ": " << "\33[31m" << "New Packet Sent" << "\33[0m" << endl;
        cout << "Destination Addresses: ";
        if (dest[0]) cout << 1 << " ";
        if (dest[1]) cout << 2 << " ";
        if (dest[2]) cout << 3 << " ";
        if (dest[3]) cout << 4 << " ";
	if (dest[4]) cout << 5 << " ";
	if (dest[5]) cout << 6 << " ";
	if (dest[6]) cout << 7 << " ";
	if (dest[7]) cout << 8 << " ";
        cout << endl;
        cout << "Packet Value: " << (int) pkt_data.data << endl;
        cout << "Sender ID: " << (int) source_id.read() + 1 << endl;
        cout << ".........................." << endl;

        round_count++;

        wait();

        /////wait for 1 to 3 clock periods/////////////////////
        wait(1 + (rand() % 3));
    }

}


