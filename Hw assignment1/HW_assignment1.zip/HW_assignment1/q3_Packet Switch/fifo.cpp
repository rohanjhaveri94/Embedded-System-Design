/*****************************************************************************

  fifo.cpp - This is the functionality file for the SystemC structure "fifo".

 *****************************************************************************/

#include "pkt.h"
#include "fifo.h"

void fifo::pkt_in(const pkt& data_pkt) {
    regs[pntr++] = data_pkt;
    empty = false;
    if (pntr == 8) full = true;
}

pkt fifo::pkt_out() {
    pkt temp;
    temp = regs[0];
    if (--pntr == 0) empty = true;
    else {
        regs[0] = regs[1];
        regs[1] = regs[2];
        regs[2] = regs[3];
	regs[3] = regs[4];
	regs[4] = regs[5];
	regs[5] = regs[6];
	regs[6] = regs[7];
	regs[7] = regs[8];
    }
    return (temp);
}
