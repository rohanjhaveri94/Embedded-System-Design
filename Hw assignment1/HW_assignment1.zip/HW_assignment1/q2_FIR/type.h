#ifndef TYPE_H
#define TYPE_H

#include "systemc.h"

//data width in simulation
#define 	DATA_WIDTH		32

//data type in simulation
typedef sc_int<DATA_WIDTH> data_type;

#endif

