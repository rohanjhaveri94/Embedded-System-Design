#ifndef MAIN_H
#define MAIN_H

#include "type.h"

//number of stages in FIR filter
#define NUM_TAP 12

//coefficients of 8-tap FIR filter
const data_type COEFF[NUM_TAP] = {472, 34, 348, 181, 295, 361, 430, 260, 179, 151, 81, 68};

#endif
