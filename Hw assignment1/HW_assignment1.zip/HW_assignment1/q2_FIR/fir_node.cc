#include "fir_node.h"

void FirNode::proc_firnode() {
    //[Missing] multiply recieved data with its own coefficients and send to accumulator
   
     mul_out->write(data_in->read() * coeff);
    //[Missing] pass on current data to next tap
     
     data_out->write(data_in->read());

}
