#ifndef ACCUMULATOR_H
#define ACCUMULATOR_H

#include <systemc.h>
#include "type.h"
#include "main.h"

class Accumulator : public sc_module {
public:
    sc_in<bool> clock;
    //dummy port to connect the data_out of last FirNode instance
    sc_in<data_type> data_in;
    //ports to gather multiplication results for FirNodes
    sc_in<data_type> mul_in[NUM_TAP];
    //port to write results to memory
    sc_out<data_type> data_out;

    void proc_accumulator();

    SC_HAS_PROCESS(Accumulator);

    Accumulator(sc_module_name _name) {

        SC_METHOD(proc_accumulator);
        sensitive << clock.pos();
    }

private:
    int i;
    data_type sum; //temp variable for sum
};

#endif
