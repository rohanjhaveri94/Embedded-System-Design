#ifndef FIR_NODE_H
#define FIR_NODE_H

#include <systemc.h>
#include "type.h"

class FirNode : public sc_module {
public:
    sc_in<bool> clock;
    sc_in<data_type> data_in;
    sc_out<data_type> data_out;
    sc_out<data_type> mul_out;


    void proc_firnode();

    SC_HAS_PROCESS(FirNode);

    FirNode(sc_module_name _name, data_type _coeff) {
        SC_METHOD(proc_firnode);
        sensitive << clock.pos();

        coeff = _coeff;
    }

private:
    data_type coeff;
};

#endif
