#include "systemc.h"
#include "type.h"
#include "mem.h"
#include "fir_node.h"
#include "accumulator.h"
#include "main.h"

int sc_main(int argc, char* argv[]) {
    int i;
    char nodeName[19];

    //signals to connect data and mul ports
    sc_signal<data_type> data_sig[NUM_TAP + 1];
    sc_signal<data_type> mul_sig[NUM_TAP];
    sc_signal<data_type> result;

    //system clock
    sc_clock* sys_clock;

    //pointer for modules
    Memory* mem;
    FirNode * firnodes[NUM_TAP];
    Accumulator* accu;


    // create global clock
    sys_clock = new sc_clock("SYSTEM_CLOCK", 1, SC_NS);
    
    //Construct Memory and Accumulator modules
    mem = new Memory("MEMORY");
    accu = new Accumulator("ACCUMULATOR");
    //Construct FirNodes (assign coefficient to each node)
    for (i = 0; i < NUM_TAP; i++) {
        sprintf(nodeName, "FIR_NOD[%d]", i);
        firnodes[i] = new FirNode(nodeName, COEFF[i]);
    }

    //connect ports of memory
    mem->data_read(data_sig[0]);
    mem->clock(*sys_clock);
    mem->data_write(result);

    //[Missing] connect ports of fir_nodes
    for (i = 0; i <= NUM_TAP-1; i++) {
        firnodes[i]->clock(*sys_clock);
        firnodes[i]->data_in(data_sig[i]);
        firnodes[i]->data_out(data_sig[i + 1]);
        firnodes[i]->mul_out(mul_sig[i]);
    }
    
    //[Missing] connect ports of accumulator
    accu->clock(*sys_clock);
    accu->data_in(data_sig[NUM_TAP]);
    for (i = 0; i <= NUM_TAP-1; i++) {
        accu->mul_in[i](mul_sig[i]);
    }
    accu->data_out(result);

    //start simulation
    sc_start(300, SC_NS);
    return 0;
}
