#include "accumulator.h"

void Accumulator::proc_accumulator() {
    //[Missing] sum up multiplication results gathered from FirNodes (using declared variable "sum")
    sum = 0;
    for (i = 0; i <=NUM_TAP-1; i++)
    {
        sum = sum + (mul_in[i]->read());
    }
    //[Missing] send sum to memory module
    data_out->write(sum);
}
