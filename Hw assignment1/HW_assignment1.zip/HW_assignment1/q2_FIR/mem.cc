#include "mem.h"

void Memory::proc_memory() {
    if ((data_count != memory_size)) {
        data_read->write(storage[data_count]);
        storage[data_count] = data_write->read();
        data_count++;
    } else if (data_count == memory_size) {
        //print out content of memory (results)
        cout << "\33[32m" << sc_time_stamp() << "\33[31m" << "\t[MEMORY]: Data processed. Stop simulation..." << "\33[0m" << endl;
        cout << "\33[32m" << sc_time_stamp() << "\33[31m" << "\t[MEMORY]: Data in memory ([addr] data):" << "\33[0m" << endl;
        for (i = 0; i < memory_size; i++) {
            cout << "\33[36m";
            cout << "[" << i << "] ";
            cout.width(8);
            cout << storage[i] << "\t";
            if (i % 8 == 7) cout << endl;
            cout << "\33[0m";
        }
        //[Missing] stop SystemC simulation
	sc_stop();

    }
 
}
