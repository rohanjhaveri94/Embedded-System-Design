  //===========================================
 // Function : Asynchronous SRAM 
//===========================================
#include "systemc.h"

#define DATA_WIDTH        8 
#define ADDR_WIDTH        15 
#define RAM_DEPTH         1 << ADDR_WIDTH

SC_MODULE (RAM) {
  // ----- Declare Input/Output ports -----
	//test_RAM	*test_RAM0	
	//RAM	*RAM0;
  	sc_in < sc_uint<14> > 	Addr ;      // 14 bit address 
  	sc_in < bool > 			bWE;       // Write enable
  	sc_in < bool > 			bCE;      // Cell enable
  	sc_in < sc_uint<8> > 	InData;	 // 8-Bit input data
  	sc_out < sc_uint<8> > 	OutData;// 8-Bit output data

  // ----- Internal variables -----

	unsigned char word[16384];				// Character array of 16K*8 size(not 32K*8)

// Declaring read_write method for implementing read/write functions on 8-bit row

	
 // ----- Code Starts Here ----- 
int sc_main(int ,char* )
{
  // Memory Write Block 
 // Write Operation : When we = 1, ce = 1
// If WE and CE enabled (active-low), perform write operation
	void read_write(void){  
	if ( !(bWE.read()) && !(bCE.read()))
	{
		OutData.write(word[Addr.read()]);   //wrriting the data
		
		cout<<"Data written is "<<int(word[Addr.read()])<<endl; // Transfering the data written on addressed row to output
	}
  // Memory Read Block 
 // Read Operation : When we = 0, ce = 1
// If WE is disabled (1) and CE is enabled (0), perform read operation from memory to output
	else if ( (bWE.read()) && !(bCE.read()))	
	{
		word[Addr.read()]=InData.read();  //reading the data
		
		cout<<"Data read is "<< int(word[Addr.read()]) <<endl; // Transfering the read addressed data on output
	}

	
 }   
  SC_CTOR(RAM) {
  // ----- Constructor for the SC_MODULE -----


// sensitivity list
	SC_METHOD(read_write);	// Assigning read_write function for a method which will be sensitive to WE, CE, InData and Addr 
	sensitive << bWE;
	sensitive << bCE;
	sensitive << InData;
	sensitive << Addr;
  }
};
